package com.mbhit.kyancage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KyanCafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
