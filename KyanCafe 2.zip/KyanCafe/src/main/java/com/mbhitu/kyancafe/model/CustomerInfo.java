package com.mbhitu.kyancafe.model;

public class CustomerInfo {

	public String fName;
	public String phone;
	
	
	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}
