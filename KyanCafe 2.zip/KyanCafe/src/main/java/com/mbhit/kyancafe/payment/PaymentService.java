/*
 * package com.mbhit.kyancafe.payment;
 * 
 * 
 * 
 * import org.springframework.data.domain.Page; import
 * org.springframework.data.domain.Pageable;
 * 
 * public interface PaymentService {
 * 
 * public Payment doPayment(Payment payment);
 * 
 * public Payment getPayment(String id);
 * 
 * public Page<Payment> findAll(Pageable pageable);
 * 
 * }
 */