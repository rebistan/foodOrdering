package com.mbhit.kyancafe.entity;

public enum PlaceMode {
CAR,TAKEAWAY,DINEIN
}
